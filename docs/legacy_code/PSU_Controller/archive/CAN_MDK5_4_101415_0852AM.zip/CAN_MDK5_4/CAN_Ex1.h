#ifndef __CAN_EX1_H
#define __CAN_EX1_H


/* Function prototypes ------------------------------------------------------*/
static  void ADC_Init(void);
static  void DAC_Init(void);
static  void GetAddress(void);
static  void SystemClock_Config(void);
static  void task_dac_write(void const *arg);
static  void GetADC_Samples(void const *arg);

void nError_Handler(void);
void CanTxBufferMutator(uint8_t * ptrBuff,uint8_t len, uint32_t id);
#endif /// __CAN_EX1_H

