#ifndef __MAIN_H
#define __MAIN_H

/* function prototypes ------------------------------------------------------*/
static  void    ADC_Config(void);
static  void    DAC_Config(void);
static  void    Mux_Control(void);
static  void    GPIO_Config(void);
static  void    ADC_Defaults(void);
static  void    SystemClock_Config(void);
        void    DAC_Write(void);
        void    myErr_Handler(void);
        void    ADC_DataCollection(void);

#endif /* __MAIN_H */

/* ============================================================================
 *  FINIS
 * ==========================================================================*/

