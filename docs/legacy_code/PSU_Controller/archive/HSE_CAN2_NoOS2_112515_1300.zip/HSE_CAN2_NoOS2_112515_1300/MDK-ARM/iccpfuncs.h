#ifndef __ICCPFUNCS_H
#define __ICCPFUNCS_H

#include <stdint.h>

#define tickspersec 10

/* Enumerations ---------------------------------------------------------------------------------*/
typedef enum  {P_OFF, P_CV, P_CI, P_CPOT} psu_mode_t;
typedef enum  {LBLD, ESPM} Rect_t; 
typedef enum  {I_OFF, I_HLLO, I_PFL, I_STAQRY, I_STARSP, I_CTLPSU, I_FAIL} init_state_t;
typedef enum  {INIT_M, RUN, FAULT, CONFIG, DBG, MANUAL_M, SAFE_M} modestate_t;
typedef enum  {INIT, ON, OFF, MANUAL, SAFE} rectcntl_state_t;
        enum  Maxima  {M_INDEX = 129, M_ALARMS = 5};

/* Macros ---------------------------------------------------------------------------------------*/
#define BITCHK(Variable, Position) (((Variable) >> (Position)) & 1UL)
#define BITCLR(Variable, Position) ((Variable) &= ~(1UL << (Position)))
#define BITSET(Variable, Position) ((Variable) |= (1UL << (Position)))
#define BITTGL(Variable, Position) ((Variable) ^= (1UL << (Position)))

#define SCALE_REFCELL(x)   (4095 * (((2 * (x)) + 1250UL) / 2500UL))

/* Structures -----------------------------------------------------------------------------------*/
typedef struct {
            uint16_t  avg;
            uint32_t  sum;
  volatile  uint16_t  collection[129];
} Record_t;

// ICCP Run Time Profile Struct
typedef struct {
			psu_mode_t  psu_mode;               // P_CV, P_CI, P_CPOT, P_OFF
			int16_t     refelec_min_th;         // resolution 1mv/bit  -2048 = -0.5Vdc  +2047= +0.5Vdc
			int16_t     refelec_max_th;         // resolution 1mv/bit  -2048 = -0.5Vdc  +2047= +0.5Vdc
      int16_t     demandsetpoint;         // programmable set point for reference electrodes
			uint16_t    rec_vset;               // resolution 1mv/bit 4095 = Full Scale
			uint16_t    rec_vset_max_th;        // resolution 100mv/bit 4095 = Full Scale
			uint16_t    rec_vset_min_th;        // resolution 100mv/bit
			uint16_t    rec_fs_vset;            // resolution = vset_fs / 4095 ex 63V/4095 = 15mA/bit.
                                          // for a 54V rect. This would be the 0V point/63v=630bits
			uint16_t    rec_iset;               // resolution = iset_fs/4095 ex. 125A/4095 = 30mA/bit
			uint16_t    rec_iset_max_th;        // resolution 1A/bit
			uint16_t    rec_iset_min_th;        // resolution 1A/bit
			uint16_t    rec_fs_iset;            // resolution 1A/bit 
			uint16_t    alarm_reg_mask;         // 0=bit masked 1=active, same bit mapping as alarm register
			uint16_t    self_test_int;          // interval self test is run at in minutes/bit 0= disbaled
			uint8_t     adc_smp_int;            // interval adc samples are placed into 128 sample array 
                                          // mS/bit 0=uses real time values for debug purposes
			uint8_t     control_int;            // interval the rectifer output current is updated based
                                          // on the ref elec AVG buffers. second/bit 
			uint32_t    tsts_active;            // bit mapped to each test in the self test routine, to
                                          // allow us to select which tests will be run
			uint8_t     refelec_active;         //              
      uint8_t     refeleclongname[4][16]; // 16 character long name descriptor for each 
                                          // reference electrode sensor
} IccpPrfParam_t;                         // Iccp Profile Parameters

typedef struct {
	IccpPrfParam_t  pflparams;
	init_state_t    init_state;       // {I_OFF, I_HLLO, I_PFL, I_STA, I_FAIL } init_state_t;
	uint16_t		    AlmReg;		        // bit  0: output on\off 0=off
                                    // bit  1: DCOK 
                                    // bit  2: ACOK
                                    // bit  3: RECT SUM FLT
                                    // bit  4: Manual Mode 0= auto 1= manual
                                    // bit  5: output on\off 0=off
                                    // bit  6: ref_elec 0=passing 1=at least one refelec is failed
                                    // bit  7: communications fault CAN stopped for >2 sec
                                    // bit  8: surge protector flt detected
                                    // bit  9: Current Imbalance
                                    // bit 10: Door Status 0= closed 1=open
                                    // bit 11: Last Self Test 0=failed 1=passed
                                    // bit 12:
                                    // bit 13:
                                    // bit 14:  
                                    // bit 15: 
	uint32_t        TestStaReg;       // bit  0: test1
                                    // bit  1: test2 
                                    // bit  2: 
                                    // bit  3: 
                                    // bit  4-31:
	uint8_t         ModelNumber[16];
	uint8_t		      SerialNumber[16];
	uint8_t		      FirmwareVers[16];
  uint8_t         IndexCounter;
  uint8_t         Temperature;
  uint8_t	        DC_ADDR;
	uint16_t        nodeadr_adc;
  uint16_t        IrdNode;
	Record_t        RefCell[4];
  Record_t        Vrdbk;
	Record_t        Irdbk[4];
	uint16_t	      NODE_ADDR;
	uint16_t        dacpgm;
	uint16_t        stacnt;           // counts of successful status transmissions to LCD
	uint16_t        Status;           // bit 0  received request for "cn_hello" 
                                    // bit 1  sent cn_hello response 
                                    // bit 2  rxd request for PROFILE DATA "cn_prfupl" 
                                    // bit 3  sent all profile data 
                                    // bit 4  rxd request for status "cn_staqry" 
                                    // bit 5  sent all status data  
                                    // bit 6  no LCD host error no can hello rxd after 
                                    // 1 minute power on. 
                                    // bit 7  Flash write or read error, cant get or 
                                    // set config params
                                    // bit 8  CAN2 no cn_hello response from Liqua Blades
} SysData_t;

/* Structure instantiations ---------------------------------------------------------------------*/
extern SysData_t  SysData;

/* Furnction prototypes -------------------------------------------------------------------------*/
        void        DAC_Write(void);
        void        Init_Iccp(void);
        void        IccpDoIccp(void);
        void        TaskDispatch(void);
        void        LED_HeartBeat(void);
        void        GetADC_Samples(void);
        void        Iccp_GetRefCells(void);
        void        Iccp_GetAlarmStatus(void);
        void        WriteProfileStructToNor(IccpPrfParam_t *pfl, uint8_t prflidx);
        void        ReadProfileStructFromNor(IccpPrfParam_t *pfl, uint8_t prflidx);
        void        CopyProfileStructRam2Ram(IccpPrfParam_t *pflsrc,IccpPrfParam_t *pfldst);
        uint8_t     GetNodeAddress(uint16_t adcval);
static  uint8_t     RefCell_BoundsCheck(uint8_t index);

#endif /* __ICCPFUNCS_H */
/*=============================================================================
 *  end of file
 *===========================================================================*/

