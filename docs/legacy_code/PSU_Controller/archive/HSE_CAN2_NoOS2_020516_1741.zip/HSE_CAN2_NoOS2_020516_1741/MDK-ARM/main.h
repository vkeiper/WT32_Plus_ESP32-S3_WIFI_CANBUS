#ifndef __MAIN_H
#define __MAIN_H

#define ADC_SAMPLE_CYCLES ADC_SAMPLETIME_28CYCLES

/* function prototypes ------------------------------------------------------*/
static  void    ADC_Config(void);
static  void    DAC_Config(void);
static  void    GPIO_Config(void);
static  void    ClearADC_Params(void);
static  void    GPIO_IccpDefaults(void);
static  void    SystemClock_Config(void);
        void    DAC_Write(void);
        void    myErr_Handler(void);
        void    ADC_DataCollection(void);

#endif /* __MAIN_H */

/* ============================================================================
 *  FINIS
 * ==========================================================================*/

