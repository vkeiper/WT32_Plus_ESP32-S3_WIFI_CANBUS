#ifndef __MAIN_H
#define __MAIN_H

/* function prototypes ------------------------------------------------------*/
static  void  ADC_Config(void);
static  void  DAC_Config(void);
static  void  GPIO_Config(void);
static  void  SystemClock_Config(void);
        void  DAC_Write(void);
        void  myErr_Handler(void);
        void  GetADC_Totals(void);   

#endif /* __MAIN_H */

/* ============================================================================
 *  FINIS
 * ==========================================================================*/

