/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  *
  * COPYRIGHT(c) 2015 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "main.h"
#include "iccpfuncs.h"
#include <stm32f4xx.h>
#include <stm32f4xx_hal.h>
#include "iccp_canfuncs.h"
#include <stm32f4xx_hal_conf.h>
#include "iccp_can_stm32f446.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
/* USER CODE END PV */

/* Handles ------------------------------------------------------------------*/
/* USER CODE BEGIN Handles */
/* Handles ------------------------------------------------------------------*/
extern  CAN_HandleTypeDef       CanHandle;
        ADC_HandleTypeDef       hADC1;
        DAC_HandleTypeDef       hDAC1;
        ADC_ChannelConfTypeDef  sConfigADC;
/* USER CODE END Handles */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
/* USER CODE END PFP */
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */
__IO  uint32_t uADC_ValConv;
      int16_t setDAC = 0;

/*=============================================================================
 * Description: Set program voltage
 *===========================================================================*/
void DAC_Write(void)
{
  
  HAL_DAC_SetValue(&hDAC1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, SysData.dacpgm);
}
/*=============================================================================
 * Description: Analog/Digital conversion complete 
 *===========================================================================*/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hADC1)
{
  uint8_t rf_index, sum_index;

  switch (sConfigADC.Channel) 
  {  
    /// PSU Address
    case ADC_CHANNEL_15:
      uADC_ValConv = HAL_ADC_GetValue(hADC1);
      sConfigADC.Channel = ADC_CHANNEL_10;
    break;

    /// Reference cell #1
    case ADC_CHANNEL_10:
        uADC_ValConv = HAL_ADC_GetValue(hADC1);
        SysData.RefCell[0].collection[0] = uADC_ValConv;
        SysData.RefCell[0].collection[SysData.IndexCounter] = SysData.RefCell[0].collection[0];
        sConfigADC.Channel = ADC_CHANNEL_11;
    break;

    /// Reference cell #2
    case ADC_CHANNEL_11:
        uADC_ValConv = HAL_ADC_GetValue(hADC1);
        SysData.RefCell[1].collection[0] = uADC_ValConv;
        SysData.RefCell[1].collection[SysData.IndexCounter] = SysData.RefCell[1].collection[0];
        sConfigADC.Channel = ADC_CHANNEL_12;
    break;

    /// Reference cell #3
    case ADC_CHANNEL_12:
        uADC_ValConv = HAL_ADC_GetValue(hADC1);
        SysData.RefCell[2].collection[0] = uADC_ValConv;
        SysData.RefCell[2].collection[SysData.IndexCounter] = SysData.RefCell[2].collection[0];
        sConfigADC.Channel = ADC_CHANNEL_13;
    break;

    /// Reference cell #4
    case ADC_CHANNEL_13:
        uADC_ValConv = HAL_ADC_GetValue(hADC1);
        SysData.RefCell[3].collection[0] = uADC_ValConv;
        SysData.RefCell[3].collection[SysData.IndexCounter] = SysData.RefCell[3].collection[0];
        SysData.IndexCounter++;
        sConfigADC.Channel = ADC_CHANNEL_15;
    break;

//    /// Current monitor 1
//    case ADC_CHANNEL_1:
//        uADC_ValConv = HAL_ADC_GetValue(hADC1);
//        sConfigADC.Channel = ADC_CHANNEL_2;
//    break;

//    /// Current monitor 2
//    case ADC_CHANNEL_2:
//        uADC_ValConv = HAL_ADC_GetValue(hADC1);
//        sConfigADC.Channel = ADC_CHANNEL_3;
//    break;

//        /// Voltage monitor 1
//    case ADC_CHANNEL_3:
//        uADC_ValConv = HAL_ADC_GetValue(hADC1);
//        sConfigADC.Channel = ADC_CHANNEL_14;
//    break;

//        /// Temperature
//    case ADC_CHANNEL_14:
//        uADC_ValConv = HAL_ADC_GetValue(hADC1);
//        sConfigADC.Channel = ADC_CHANNEL_15;
//    break;

    default:
      break;
  }
  
  if (SysData.IndexCounter > M_SAMPLES)
  {
    SysData.IndexCounter = 1;

    for (rf_index = 0; rf_index < M_REFCELLS; rf_index++)
    {
      for (sum_index = 1; sum_index < (M_SAMPLES + 1); sum_index++)
      {
        SysData.RefCell[rf_index].sum += SysData.RefCell[rf_index].collection[sum_index];
      }
    }
    SysData.RefCell[0].avg = SysData.RefCell[0].sum >> 7;
    SysData.RefCell[1].avg = SysData.RefCell[1].sum >> 7;
    SysData.RefCell[2].avg = SysData.RefCell[2].sum >> 7;
    SysData.RefCell[3].avg = SysData.RefCell[3].sum >> 7;
  }
  
  SysData.RefCell[0].sum = 0;
  SysData.RefCell[1].sum = 0;
  SysData.RefCell[2].sum = 0;
  SysData.RefCell[3].sum = 0;
}
/*=============================================================================
 * Description: My error handler
 *===========================================================================*/
void myErr_Handler()
{
  for (;;)
  {
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    HAL_Delay(10);
  }
}
/*=============================================================================
 * Description: Main
 *===========================================================================*/
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  GPIO_Config();
  ADC_Config();
//  CAN1_Init();
  DAC_Config();

  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
    /* USER CODE END WHILE */
//    /* USER CODE BEGIN 3 */
//    CAN_Run();
    TaskDispatch();
  }
  /* USER CODE END 3 */
}
/*=============================================================================
 * Description: System Clock Configuration
 *===========================================================================*/
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  __PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType  = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState        = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState    = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource   = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM        = 5;
  RCC_OscInitStruct.PLL.PLLN        = 180;
  RCC_OscInitStruct.PLL.PLLP        = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ        = 2;
  RCC_OscInitStruct.PLL.PLLR        = 2;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  HAL_PWREx_ActivateOverDrive();

  RCC_ClkInitStruct.ClockType       = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1
                                    | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource    = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider   = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider  = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider  = RCC_HCLK_DIV16;       /// 11.25 MHz
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);

//  HAL_RCC_MCOConfig(RCC_MCO2, RCC_MCO2SOURCE_SYSCLK, RCC_MCODIV_5);

  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
}
/*=============================================================================
 * Description: General purpose input/output initialization
 *===========================================================================*/
void GPIO_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __GPIOH_CLK_ENABLE();
  __GPIOC_CLK_ENABLE();
  __GPIOB_CLK_ENABLE();
  __GPIOA_CLK_ENABLE();

  /* Configure GPIO pin : PC13 LED Heart beat */
  GPIO_InitStruct.Pin       = GPIO_PIN_13;
  GPIO_InitStruct.Mode      = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull      = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* Configure GPIO pin : PC9 Microcontroller oscillator output(2) */
//  GPIO_InitStruct.Pin       = GPIO_PIN_9;
//  GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
//  GPIO_InitStruct.Pull      = GPIO_NOPULL;
//  GPIO_InitStruct.Speed     = GPIO_SPEED_LOW;
//  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
//  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}
/*=============================================================================
 * Description: Analog/Digital initialization
 *===========================================================================*/
static void ADC_Config(void)
{
  
  /* Configure the global features of the ADC
    (Clock, Resolution, Data Alignment and number of conversion) */
  hADC1.Instance                      = ADC1;
  hADC1.Init.ClockPrescaler           = ADC_CLOCKPRESCALER_PCLK_DIV6;   /// 1.875 Mhz
  hADC1.Init.Resolution               = ADC_RESOLUTION12b;
  hADC1.Init.ScanConvMode             = ENABLE;
  hADC1.Init.ContinuousConvMode       = ENABLE;
  hADC1.Init.DiscontinuousConvMode    = DISABLE;
  hADC1.Init.NbrOfDiscConversion      = 0;
  hADC1.Init.ExternalTrigConvEdge     = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hADC1.Init.ExternalTrigConv         = ADC_EXTERNALTRIGCONV_T1_CC1;
  hADC1.Init.DataAlign                = ADC_DATAALIGN_RIGHT;
  hADC1.Init.NbrOfConversion          = 5;
  hADC1.Init.DMAContinuousRequests    = DISABLE;
  hADC1.Init.EOCSelection             = EOC_SINGLE_CONV;

  if (HAL_ADC_Init(&hADC1) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PC0, REF_CELL_0 */
  sConfigADC.Channel       = ADC_CHANNEL_10;
  sConfigADC.Rank          = 2;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PC1, REF_CELL_1 */
  sConfigADC.Channel       = ADC_CHANNEL_11;
  sConfigADC.Rank          = 3;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PC2, REF_CELL_2 */
  sConfigADC.Channel       = ADC_CHANNEL_12;
  sConfigADC.Rank          = 4;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PC3, REF_CELL_3 */
  sConfigADC.Channel       = ADC_CHANNEL_13;
  sConfigADC.Rank          = 5;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PA1, IMON_0 */
  sConfigADC.Channel       = ADC_CHANNEL_1;
  sConfigADC.Rank          = 6;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PA2, IMON_1 */
  sConfigADC.Channel       = ADC_CHANNEL_2;
  sConfigADC.Rank          = 7;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {   
      myErr_Handler();
  }

  /* Configure ADC channel PA3, VMON */
  sConfigADC.Channel       = ADC_CHANNEL_3;
  sConfigADC.Rank          = 8;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  /* Configure ADC channel PA14, Temperature */
  sConfigADC.Channel       = ADC_CHANNEL_14;
  sConfigADC.Rank          = 9;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

//  /* Configure ADC channel PA6, IMON_2 */
//  sConfigADC.Channel       = ADC_CHANNEL_6;
//  sConfigADC.Rank          = 10;

//  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
//  {
//      myErr_Handler();
//  }

//  /* Configure ADC channel PA7, IMON_3 */
//  sConfigADC.Channel       = ADC_CHANNEL_7;
//  sConfigADC.Rank          = 11;

//  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
//  {
//      myErr_Handler();
//  }

  /* Configure ADC channel PA15, NODE_ADDR */
  sConfigADC.Channel       = ADC_CHANNEL_15;
  sConfigADC.Rank          = 1;
  sConfigADC.SamplingTime  = ADC_SAMPLETIME_28CYCLES;
  sConfigADC.Offset        = 0;

  if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
  {
      myErr_Handler();
  }

  if (HAL_ADC_Start_IT(&hADC1) != HAL_OK)
  {
      myErr_Handler();
  }
}
/*=============================================================================
 * Description: Digital/Analog initialization
 *===========================================================================*/
static void DAC_Config(void)
{
  DAC_ChannelConfTypeDef  sConfigDAC;

  hDAC1.Instance = DAC;

  if (HAL_DAC_Init(&hDAC1) != HAL_OK)
  {
      myErr_Handler();
  }

  sConfigDAC.DAC_OutputBuffer =  DAC_OUTPUTBUFFER_DISABLE;
  sConfigDAC.DAC_Trigger      =  DAC_TRIGGER_NONE;

  if (HAL_DAC_ConfigChannel(&hDAC1, &sConfigDAC, DAC_CHANNEL_1) != HAL_OK)
  {
      myErr_Handler();
  }

  if (HAL_DAC_Start(&hDAC1, DAC_CHANNEL_1) != HAL_OK)
  {
      myErr_Handler();
  }
  
  SysData.dacpgm = 1638;

  HAL_DAC_SetValue(&hDAC1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, SysData.dacpgm);
}
/*=============================================================================
 *
 *===========================================================================*/
/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/
/*=============================================================================
 *  FINIS
 *===========================================================================*/

