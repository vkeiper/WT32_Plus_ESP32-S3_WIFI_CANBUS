/**
  ******************************************************************************
  * File Name          : stm32f4xx_hal_msp.c
  * Description        : This file provides code for the MSP Initialization 
  *                      and de-Initialization codes.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2015 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "main.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * Initializes the Global MSP.
  */
void HAL_MspInit(void)
{
  /* USER CODE BEGIN MspInit 0 */

  /* USER CODE END MspInit 0 */

  HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

  /* System interrupt init*/
  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);

  /* USER CODE BEGIN MspInit 1 */

  /* USER CODE END MspInit 1 */
}
/**
 *  @brief  ADC MSP Initializtion
 *          This function configures the hardware resources used in this example:
 *            - Peripheral's clock enable
 *            - Peripheral's GPIO configuration
 *  @param  hADC: ADC handle pointer
 *  @retval None
 */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hADC)
{
  GPIO_InitTypeDef    GPIO_InitStructADC;

  if (hADC->Instance == ADC1) 
  {
      /* Peripheral clock enable */
      __ADC1_CLK_ENABLE();

    /** ADC1 GPIO Configuration: 
     *  PC0  ---> ADC1_IN10:  Reference cell 1
     *  PC1  ---> ADC1_IN11:  Reference cell 2
     *  PC2  ---> ADC1_IN12:  Reference cell 3
     *  PC3  ---> ADC1_IN13:  Reference cell 4 
     *  PC4  ---> ADC1_IN14:  Current sense X
     *  PC5  ---> ADC1_IN15:  Current sense Y
     *  PA1  ---> ADC1_IN1:   Voltage monitor
     *  PA2  ---> ADC1_IN2:   Current monitor 1
     *  PA3  ---> ADC1_IN3:   Current monitor 2
     *  PA6  ---> ADC1_IN6:   PSU addres
     *  PA7  ---> ADC1_IN7:   Temperature 
     */
    
      GPIO_InitStructADC.Pin      = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3
                                  | GPIO_PIN_4 | GPIO_PIN_5;
      GPIO_InitStructADC.Mode     = GPIO_MODE_ANALOG;
      GPIO_InitStructADC.Pull     = GPIO_NOPULL;
      GPIO_InitStructADC.Speed    = GPIO_SPEED_FAST;
      HAL_GPIO_Init(GPIOC, &GPIO_InitStructADC);

//      GPIO_InitStructADC.Pin       = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_6
//                                   | GPIO_PIN_7;
//      HAL_GPIO_Init(GPIOA, &GPIO_InitStructADC);
  }
  else
  {
    myErr_Handler();
  }

  HAL_NVIC_SetPriority(ADC_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(ADC_IRQn);
}
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hADC)
{
  if (hADC->Instance == ADC1)
  {
    /* Disable ADC clock */  
    __HAL_RCC_ADC1_CLK_DISABLE();

    __HAL_RCC_ADC_FORCE_RESET();
    __HAL_RCC_ADC_RELEASE_RESET();

    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_6 | GPIO_PIN_7);
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | 
                    GPIO_PIN_4 | GPIO_PIN_5);
  }
  else
  {
    myErr_Handler();
  }
}
void HAL_DAC_MspInit(DAC_HandleTypeDef *hDAC)
{
  GPIO_InitTypeDef  GPIO_InitStructDAC;

  if (hDAC->Instance == DAC) 
  {
    /* Enable DAC clock */
    __HAL_RCC_DAC_CLK_ENABLE();

    GPIO_InitStructDAC.Pin    = GPIO_PIN_4;
    GPIO_InitStructDAC.Mode   = GPIO_MODE_ANALOG;
    GPIO_InitStructDAC.Pull   = GPIO_NOPULL;
    GPIO_InitStructDAC.Speed  = GPIO_SPEED_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStructDAC);
  }
  else
  {
    myErr_Handler();
  }
}
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hDAC)
{
  if (hDAC->Instance == DAC) 
  {
    __DAC_CLK_DISABLE();

    __HAL_RCC_DAC_FORCE_RESET();
    __HAL_RCC_DAC_RELEASE_RESET();

    /* PA4 -----> DAC_OUT1 */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);
  }
  else
  {
    myErr_Handler();
  }
}
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/*=============================================================================
 *  FINIS
 *===========================================================================*/


