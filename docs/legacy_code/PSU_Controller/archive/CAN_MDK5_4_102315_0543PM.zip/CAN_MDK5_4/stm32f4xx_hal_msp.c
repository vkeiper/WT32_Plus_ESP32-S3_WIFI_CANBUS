#include "stm32f4xx_hal.h"              // Keil::Device:STM32Cube HAL:Common
#include "CAN_Ex1.h"

#if 0
void HAL_MspInit(void)
{
    HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);
}
#endif
void HAL_ADC_MspInit(ADC_HandleTypeDef *hADC)
{
    GPIO_InitTypeDef    GPIO_InitStructADC;

    if (hADC->Instance == ADC1) 
    {
        /* Peripheral clock enable */
        __ADC1_CLK_ENABLE();

      /** ADC1 GPIO Configuration: 
        * PC0  -----> ADC1_IN10
        * PC1  -----> ADC1_IN11
        * PC2  -----> ADC1_IN12
        * PC3  -----> ADC1_IN13 
        * PC4  -----> ADC1_IN14
        * PC5  -----> ADC1_IN15
        * PA1  -----> ADC1_IN1
        * PA2  -----> ADC1_IN2
        * PA3  -----> ADC1_IN3
        * PA6  -----> ADC1_IN6
        * PA7  -----> ADC1_IN7 
       */
      
        GPIO_InitStructADC.Pin      = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3
                                    | GPIO_PIN_4 | GPIO_PIN_5;
        GPIO_InitStructADC.Mode     = GPIO_MODE_ANALOG;
        GPIO_InitStructADC.Pull     = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOC, &GPIO_InitStructADC);

        GPIO_InitStructADC.Pin       = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_6
                                     | GPIO_PIN_7;
        GPIO_InitStructADC.Mode      = GPIO_MODE_ANALOG;
        GPIO_InitStructADC.Pull      = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStructADC);
    }
    else
    {
        nError_Handler();
    }

    HAL_NVIC_SetPriority(ADC_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(ADC_IRQn);
}
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hADC)
{
    if (hADC->Instance == ADC1)
    {
      /* Disable ADC clock */  
      __ADC1_CLK_DISABLE();

      __ADC_FORCE_RESET();
      __ADC_RELEASE_RESET();

    /** ADC1 GPIO Configuration: 
      * PC0  -----> ADC1_IN10
      * PC1  -----> ADC1_IN11
      * PC2  -----> ADC1_IN12
      * PC3  -----> ADC1_IN13 
      * PC14 -----> ADC1_IN14
      * PC15 -----> ADC1_IN15
      * PA1  -----> ADC1_IN1
      * PA2  -----> ADC1_IN2
      * PA3  -----> ADC1_IN3
      * PA6  -----> ADC1_IN6
      * PA7  -----> ADC1_IN7 
     */

      HAL_GPIO_DeInit(GPIOA, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_6 | GPIO_PIN_7);
      HAL_GPIO_DeInit(GPIOC, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | 
                      GPIO_PIN_14 | GPIO_PIN_15);
    }
    else
    {
        nError_Handler();
    }
}
void HAL_DAC_MspInit(DAC_HandleTypeDef *hDAC)
{
    GPIO_InitTypeDef  GPIO_InitStructDAC;

    if (hDAC->Instance == DAC) 
    {
      /* Enable DAC clock */
      __DAC_CLK_ENABLE();

      GPIO_InitStructDAC.Pin    = GPIO_PIN_4;
      GPIO_InitStructDAC.Mode   = GPIO_MODE_ANALOG;
      GPIO_InitStructDAC.Pull   = GPIO_NOPULL;
      GPIO_InitStructDAC.Speed  = GPIO_SPEED_MEDIUM;
      HAL_GPIO_Init(GPIOA, &GPIO_InitStructDAC);
    }
    else
    {
        nError_Handler();
    }
}
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hDAC)
{
    if (hDAC->Instance == DAC) 
    {
        /* Enable DAC clock */
        __DAC_CLK_DISABLE();

        __DAC_FORCE_RESET();
        __DAC_RELEASE_RESET();

        /* PA4 -----> DAC_OUT1 */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);
    }
    else
    {
        nError_Handler();
    }
}
/*=============================================================================
 *  end of file
 *===========================================================================*/

