/*----------------------------------------------------------------------------
 *      RL-ARM - CAN
 *----------------------------------------------------------------------------
 *      Name:    CAN_Ex1.c
 *      Purpose: RTX CAN Driver usage example
 *      Rev.:    V4.70
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2013 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include "cmsis_os.h"                      	/* RTX kernel functions & defines      */
#include "stm32f4xx.h"                		/* STM32F40x register definitions      */
#include "RTX_CAN.h"                  		/* CAN Generic functions & defines     */ 
#include "Board_GLCD.h"                     /* GLCD functions prototypes           */
#include "GLCD_Config.h"               
#include "Board_ADC.h"                  
#include "stm32f4xx_hal.h"
#include "string.h"
#include "CAN_Ex1.h"               
#include "iccp_canfuncs.h"               
#include "iccpfuncs.h"
#include "Board_LED.h"                      // ::Board Support:LED

ADC_HandleTypeDef       hADC1;
DAC_HandleTypeDef       hDAC;
ADC_ChannelConfTypeDef  sConfigADC;
DAC_ChannelConfTypeDef  sConfigDAC;

// External resources vk,
extern  uint8_t     b_CANTXFlag;
extern  GLCD_FONT   GLCD_Font_16x24;     

uint32_t canbuad = 250000; //CANBaud rate of 250K

/*=============================================================================
 *
 *===========================================================================*/
osThreadId tid_send_CAN;                  /* Thread id of thread: phase_b      */
osThreadId tid_rece_CAN;                  /* Thread id of thread: phase_c      */
osThreadId tid_disp;                      /* Thread id of thread: phase_c      */

void task_send_CAN (void  const *argument);
void task_rece_CAN (void  const *argument);
void task_disp     (void  const *argument);

CAN_msg cantx_msg;

uint32_t Tx_val = 0, Rx_val = 0;           /* Global variables used for display   */

unsigned char hex_chars[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

/*=============================================================================
 *  Function for converting 1 byte to string in hexadecimal notation
 *===========================================================================*/
void Hex_Str (unsigned char hex, unsigned char *str) {
  *str++ = '0';
  *str++ = 'x';
  *str++ = hex_chars[hex >>  4];
  *str++ = hex_chars[hex & 0xF];
}
/*=============================================================================
 *  Function to getting input value
 *===========================================================================*/
uint16_t In_Get (void)
{
    int16_t val;
  
    switch (sConfigADC.Channel) 
    {
        case ADC_CHANNEL_10:
            val = SysData.RefCell[0].collection[0];
        break;

        case ADC_CHANNEL_11:
            val = SysData.RefCell[1].collection[0];
        break;

        case ADC_CHANNEL_12:
            val = SysData.RefCell[2].collection[0];
        break;

        case ADC_CHANNEL_13:
            val = SysData.RefCell[3].collection[0];
        break;

        default:
        break;
    }
    return (val >> 4);      /* Scale analog value to 8 bits      */
}
/*=============================================================================
 *  Functions for init and output of value on visual element
 *===========================================================================*/
void Out_Init (void) {

  /* Setup LCD                                                               */
  GLCD_Initialize();                    /* Initialize the GLCD               */
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
  GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen        ();
  GLCD_SetFont            (&GLCD_Font_16x24);
  GLCD_DrawString         (0, 0*24, "ICCP PSU ");
  GLCD_DrawString         (0, 1*24, "Controller ");
  GLCD_DrawString         (0, 9*24, "Demo    ");
  GLCD_DrawString(0, 4*24, " CAN at 250kbit/s   ");
  GLCD_DrawString(0, 8*24, " AD value:          ");

}
void Out_Val (void) {
  uint32_t val1, val2;
  static unsigned char disp_buf[] = " Tx:    , Rx:    ";

  val1 = Tx_val;                        /* Read values to local variable     */
  val2 = Rx_val;    

  Hex_Str(val1, &disp_buf[ 4]);         /* Display Tx and Rx values to LCD   */ 
  Hex_Str(val2, &disp_buf[13]);
  GLCD_DrawString(0, 7*24, (char *)disp_buf); /* Print string to LCD */

  GLCD_DrawBargraph (160, 8*24, 140, 20, Tx_val*100/255); /* Disp tx val on bargraph */
}
/*=============================================================================
 *  Task 1: Sends CAN message if iccp_can API sets b_CANTC_Flag
 *===========================================================================*/
void task_send_CAN (void  const *arg)  {
	
	uint32_t canid = 0;
    
	// Init ICCP CAN API, loads API sets NODE ADR, DCADR
	IccpCanApiInit();
	
	CAN_init (1, 250000);               /* CAN controller 1 hardware init, 250 kbit/s   */

	canid = (SysData.NODE_ADDR << 4 | SysData.DC_ADDR) << 12;// shift NODE Adr and DCDC adr into their respective bit positions
	
	// Setup receive objects for each CAN function, it appears this is how the Keil CAN stack functions
  // I will investigate if we can create one object for multiple CANID's later. For now this will work 
	// I my can stack for the dsPIC we passed in a mask and filter to the hardware and all mesages went 
  // into DMA that passed the filter-mask combo.	I believe these receive ojects are serving a similar function.
  CAN_rx_object (1, 2,  canid |= 0x00000200, DATA_TYPE | EXTENDED_TYPE); /* Enable reception  of 0x200 cmd  cn_hello - can hello who am i*/
  CAN_rx_object (1, 2,  canid |= 0x00000201, DATA_TYPE | EXTENDED_TYPE); /* Enable reception  of 0x201 cmd  cn_prfupl - profile upload */
  CAN_rx_object (1, 2,  canid |= 0x00000202, DATA_TYPE | EXTENDED_TYPE); /* Enable reception  of 0x202 cmd  cn_staqry - status query */
  CAN_rx_object (1, 2,  canid |= 0x00000203, DATA_TYPE | EXTENDED_TYPE); /* Enable reception  of 0x203 cmd  cn_prfdld_flash - download profile to flash*/
  CAN_rx_object (1, 2,  canid |= 0x00000204, DATA_TYPE | EXTENDED_TYPE); /* Enable reception  of 0x204 cmd  cn_prfdld_ram - download profile to RAM*/


#if defined(CAN_LOOPBACK)

  /* The activation of test mode in line below is used for enabling 
     self-testing mode when CAN controller receives the message it sends so 
     program functionality can be tested without another CAN device          */
  /* COMMENT THE LINE BELOW TO ENABLE DEVICE TO PARTICIPATE IN CAN NETWORK   */
  CAN_hw_testmode(1, CAN_BTR_SILM | CAN_BTR_LBKM); /* Loopback and           */
                                                   /* Silent Mode (self-test)*/
#endif

  CAN_start (1);    /* Start controller 1                  */
	b_CANTXFlag = 0;
	
	
    for (;;)  
    {
     
        CANDoCAN();// check if CAN cmds are in API buffer and execute all in buffer
			
        /*##- Transmit CAN1 if Flag SET ###############################*/
        if(b_CANTXFlag)
        {
            b_CANTXFlag = 0; //clear flag for next TX
            CAN_send (1, &cantx_msg, 0x0F00);  /* Send cantx_msg on CAN1       */
        }
				
        osDelay (50);  /* Do nothing for 50mS to allow other tasks time to run    */
    }
}
/* Task 2: Received CAN message -------------------------------------------- */
void task_rece_CAN (void  const *argument)  
{
    CAN_msg canrx_msg;
	uint8_t lclCanBuff[8];
	int8_t i;
  
	for (;;)  
	{
        /* When message arrives store received value to global variable Rx_val   */
        if (CAN_receive (1, &canrx_msg, 0x00FF) == CAN_OK)  
        {
            //clear buffer for population
            memset(lclCanBuff,0,sizeof(lclCanBuff));
            for ( i = 0; i < 8; i++ ) 
            {
                lclCanBuff[i] = canrx_msg.data[i];	
            }
            // move data from CANFIFO to CANAPI ring buffer
            CanApiEnqueue(canrx_msg.id, lclCanBuff,canrx_msg.len); 
        }
    }
}
/* Task 3: Run ICCP state machine also in debug mode Activate visual outputs ------------------------------------------*/
void task_disp (void  const *argument)  
{
    for (;;)  
	{

        IccpDoIccp();   // run iccp state machine*
		
		//Out_Val ();   /* Output info on visual outputs       */
			
		osDelay (100);  /* Do nothing for 100 ms  */
    }
}
/*=============================================================================
 * Mutator: CANBUS transmit buffer
 *===========================================================================*/
void CanTxBufferMutator(uint8_t * ptrBuff, uint8_t len, uint32_t id)
{
    int8_t i;
	
	b_CANTXFlag = 1;
		
    if (len > 8) {len = 8;}
		
    for ( i = 0; i < len; i++ ) 
    {
            cantx_msg.data[i] = *ptrBuff++;
    }

    cantx_msg.id      = id;
    cantx_msg.len     = len;
    cantx_msg.format  = EXTENDED_FORMAT;
    cantx_msg.type    = DATA_FRAME; 
}
/*=============================================================================
 *  Task 4: DAC output
 *===========================================================================*/
static void task_dac_write(void)
{
    Iccp_GetAlarmStatus();

    switch(SysData.pflparams.psu_mode)
    {
        case P_CI:
            if (!SysData.AlmReg)
            {
                SysData.dacpgm = SysData.pflparams.rec_iset;
            }
            else
            {
                SysData.dacpgm = P_OFF;
            }
        break;

        case P_CPOT:
            if(!SysData.AlmReg)
            {
                Iccp_GetRefCells();
            }
            else
            {
                SysData.dacpgm = P_OFF;
            }
        break;

        case P_CV:
            if (!SysData.AlmReg)
            {
                SysData.dacpgm = (uint16_t)(4095 * (float)(SysData.pflparams.rec_vset / SysData.pflparams.rec_fs_vset));
            }
            else
            {
                SysData.dacpgm = P_OFF;
            }
        break;

        default:
            SysData.dacpgm = P_OFF;
        break;
    }
        HAL_DAC_SetValue(&hDAC, DAC_CHANNEL_1, DAC_ALIGN_12B_R, SysData.dacpgm);                 
}
/*=============================================================================
 *  Get ADC samples
 *===========================================================================*/
osTimerId TmrId_GetADC_Samples;

void GetADC_Samples(void const *arg)
{
    if (SysData.IndexCounter <= M_INDEX) 
    {
        SysData.RefCell[0].collection[SysData.IndexCounter] = SysData.RefCell[0].collection[0];
        SysData.RefCell[1].collection[SysData.IndexCounter] = SysData.RefCell[1].collection[0];
        SysData.RefCell[2].collection[SysData.IndexCounter] = SysData.RefCell[2].collection[0];
        SysData.RefCell[3].collection[SysData.IndexCounter] = SysData.RefCell[3].collection[0];
        SysData.Irdbk[0].collection[SysData.IndexCounter]   = SysData.Irdbk[0].collection[0];
        SysData.Irdbk[1].collection[SysData.IndexCounter]   = SysData.Irdbk[1].collection[0];
        SysData.Irdbk[2].collection[SysData.IndexCounter]   = SysData.Irdbk[2].collection[0];
        SysData.Irdbk[3].collection[SysData.IndexCounter]   = SysData.Irdbk[3].collection[0];
        SysData.Vrdbk.collection[SysData.IndexCounter]      = SysData.Vrdbk.collection[0];
                              
        SysData.RefCell[0].sum  += SysData.RefCell[0].collection[SysData.IndexCounter];
        SysData.RefCell[1].sum  += SysData.RefCell[1].collection[SysData.IndexCounter];
        SysData.RefCell[2].sum  += SysData.RefCell[2].collection[SysData.IndexCounter];
        SysData.RefCell[3].sum  += SysData.RefCell[3].collection[SysData.IndexCounter];
        SysData.Irdbk[0].sum    += SysData.Irdbk[0].collection[SysData.IndexCounter];
        SysData.Irdbk[1].sum    += SysData.Irdbk[1].collection[SysData.IndexCounter];
        SysData.Irdbk[2].sum    += SysData.Irdbk[2].collection[SysData.IndexCounter];
        SysData.Irdbk[3].sum    += SysData.Irdbk[3].collection[SysData.IndexCounter];
        SysData.Vrdbk.sum       += SysData.Vrdbk.collection[SysData.IndexCounter];

        SysData.IndexCounter++;
    }
  
    if (SysData.IndexCounter > M_INDEX) 
    {
        SysData.RefCell[0].avg  = (SysData.RefCell[0].sum >> 7);
        SysData.RefCell[1].avg  = (SysData.RefCell[1].sum >> 7);
        SysData.RefCell[2].avg  = (SysData.RefCell[2].sum >> 7);
        SysData.RefCell[3].avg  = (SysData.RefCell[3].sum >> 7);
        SysData.Irdbk[0].avg    = (SysData.Irdbk[0].sum >> 7);
        SysData.Irdbk[1].avg    = (SysData.Irdbk[1].sum >> 7);
        SysData.Irdbk[2].avg    = (SysData.Irdbk[2].sum >> 7);
        SysData.Irdbk[3].avg    = (SysData.Irdbk[3].sum >> 7);
        SysData.Vrdbk.avg       = (SysData.Vrdbk.sum >> 7);
    
        SysData.IndexCounter    = 1;
        SysData.RefCell[0].sum  = 0;
        SysData.RefCell[1].sum  = 0;
        SysData.RefCell[2].sum  = 0;
        SysData.RefCell[3].sum  = 0;
        SysData.Irdbk[0].sum    = 0;
        SysData.Irdbk[1].sum    = 0;
        SysData.Irdbk[2].sum    = 0;
        SysData.Irdbk[3].sum    = 0;
        SysData.Vrdbk.sum       = 0;  
    }
}
/*=============================================================================
 *  HAL ADC conversion complete callback 
 *===========================================================================*/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hADC1)
{
    switch (sConfigADC.Channel) {
        case ADC_CHANNEL_10:
            SysData.RefCell[0].collection[0]    = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_11:
            SysData.RefCell[1].collection[0]    = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_12:
            SysData.RefCell[2].collection[0]    = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_13:
            SysData.RefCell[3].collection[0]    = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_1:
            SysData.Irdbk[0].collection[0]      = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_2:
            SysData.Irdbk[1].collection[0]      = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_3:
            SysData.Vrdbk.collection[0]         = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_6:
            SysData.Irdbk[2].collection[0]      = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_7:
            SysData.Irdbk[3].collection[0]      = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_14:
            SysData.Temperature                 = HAL_ADC_GetValue(hADC1);
        break;

        case ADC_CHANNEL_15:
            SysData.nodeadr_adc                 = HAL_ADC_GetValue(hADC1);
        break;

        default:
        break;
    }
}
/** @Author Vince Keiper
  * @brief  CAN TX Buffer Mutator for Keil RTX CAN library.  
  *         This function sets the CAN_msg struct type id,DLC, and tx data buffer:
  *         - Also sets boolean CANTx Flag which triggers CANThread to TX 
  *         - the tx buffer
  *         
  * @param  ptrBuff: pointer to lclbuffer in caller
  * @param  len: length of CANTX buffer, qty bytes to send 0-8
  * @param  id: function ID portion of the CANID to be TX'd 
  * @retval None
  */
/*=============================================================================
 *  User defined Error_Handler
 *===========================================================================*/
void nError_Handler(void)
{
    uint8_t i;

    while (1) 
    {
        for (i = 0; i < 7; i++)
        {
            LED_On(i);
            HAL_Delay(250);
            LED_Off(i);
        }

        for (i = 7; i > 0; i--)
        {
            LED_On(i);
            HAL_Delay(250);
            LED_Off(i);
        }
    } 
}
/*=============================================================================
 *  Main: Initialize and start RTX Kernel
 *===========================================================================*/
osThreadDef(task_send_CAN, osPriorityNormal, 1, 0);
osThreadDef(task_rece_CAN, osPriorityNormal, 1, 0);
osThreadDef(task_disp    , osPriorityNormal, 1, 0);

osTimerDef(Tmr_GetADC_Samples, GetADC_Samples);

int main (void)                             /* Program execution starts here       */
{
    HAL_Init();                               /* Initialize the HAL Library          */
    SystemClock_Config();                     /* Configure the System Clock          */
    NM_GPIO_Init();
	ADC_Init();
    DAC_Init();

    LED_Initialize();

	//  TODO: Need to read profile out of FLASH before this OStimer is initialized
	//  because this interval is one of the parameters

    /// TmrId_GetADC_Samples = osTimerCreate(osTimer(Tmr_GetADC_Samples), osTimerPeriodic, NULL);
    /// osTimerStart(TmrId_GetADC_Samples, SysData.pflparams.adc_smp_int);

	Out_Init();                               /* Initialize visual outputs           */

    tid_send_CAN  = osThreadCreate(osThread(task_send_CAN ), NULL);
    tid_rece_CAN  = osThreadCreate(osThread(task_rece_CAN ), NULL);
    tid_disp      = osThreadCreate(osThread(task_disp     ), NULL);

    osDelay(osWaitForever);
}
/*=============================================================================
 *  System clock configuration
 *===========================================================================*/
static void SystemClock_Config(void) 
{
    RCC_OscInitTypeDef RCC_OscInitStruct;
    RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /* Enable Power Control clock */
    __PWR_CLK_ENABLE();

    /* The voltage scaling allows optimizing the power consumption when the
        device is clocked below the maximum system frequency (see datasheet). */
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /* Enable HSE Oscillator and activate PLL with HSE as source */
    RCC_OscInitStruct.OscillatorType 		= RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState 				= RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState 			= RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource 		= RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM 				= 25;
    RCC_OscInitStruct.PLL.PLLN 				= 336;
    RCC_OscInitStruct.PLL.PLLP 				= RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ 				= 7;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
    RCC_ClkInitStruct.ClockType 			= RCC_CLOCKTYPE_SYSCLK;
	RCC_ClkInitStruct.ClockType			    |= RCC_CLOCKTYPE_PCLK1;													
    RCC_ClkInitStruct.ClockType             |= RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource 			= RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider 		= RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider 		= RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider 		= RCC_HCLK_DIV2;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}
/*=============================================================================
 *  General Purpose configuration
 *===========================================================================*/
static void NM_GPIO_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;

    /* Enable peripheral clocks */
    __GPIOA_CLK_ENABLE();
    __GPIOB_CLK_ENABLE();
    __GPIOC_CLK_ENABLE();

    /* Configure general purpose input {PORTB}:
     *  PB1  -----> AC_OK_MICRO
     *  PB2  -----> BOOT1
     *  PB10 -----> FRONT_DOOR_ALARM
     *  PB12 -----> AC_SURGE_ALARM
     *  PB13 -----> DC_SURGE_ALARM
     *  PB15 -----> DC_OK_MICRO 
    */
    GPIO_InitStruct.Pin     = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_10
                            | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_15;
    GPIO_InitStruct.Mode    = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull    = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

     /* Configure general purpose output {PORTB}:
      * PB0  -----> Inhibit
     */
    GPIO_InitStruct.Pin         = GPIO_PIN_0;
    GPIO_InitStruct.Mode        = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull        = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

     /* Configure general purpose output {PORTC}:
      * PC13 -----> LED_Heartbeat
      * PC37 -----> Multiplexor inhibit
      * PC38 -----> Mux A
      * PC39 -----> Mux B
      * PC40 -----> Mux C
     */
    GPIO_InitStruct.Pin         = GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_13;
    GPIO_InitStruct.Mode        = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull        = GPIO_NOPULL;
    GPIO_InitStruct.Speed       = GPIO_SPEED_LOW;
    /// GPIO_InitStruct.Alternate
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}
/*=============================================================================
 *  ADC Configuration (Interrupts)
 *===========================================================================*/
static void ADC_Init(void)
{
    /* Configure the global features of the ADC
        (Clock, Resolution, Data Alignment and number of conversion) */
    hADC1.Instance                      = ADC1;
    hADC1.Init.ClockPrescaler           = ADC_CLOCKPRESCALER_PCLK_DIV4;
    hADC1.Init.Resolution               = ADC_RESOLUTION12b;
    hADC1.Init.ScanConvMode             = ENABLE;
    hADC1.Init.ContinuousConvMode       = ENABLE;
    hADC1.Init.DiscontinuousConvMode    = DISABLE;
    hADC1.Init.NbrOfDiscConversion      = 0;
    hADC1.Init.ExternalTrigConvEdge     = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hADC1.Init.ExternalTrigConv         = ADC_EXTERNALTRIGCONV_T1_CC1;
    hADC1.Init.DataAlign                = ADC_DATAALIGN_RIGHT;
    hADC1.Init.NbrOfConversion          = 11;
    hADC1.Init.DMAContinuousRequests    = DISABLE;
    hADC1.Init.EOCSelection             = EOC_SINGLE_CONV;
  
    if (HAL_ADC_Init(&hADC1) != HAL_OK)
    {
        nError_Handler();
    }

    /* Configure ADC channel PC0, REF_CELL_0 */
    sConfigADC.Channel       = ADC_CHANNEL_10;
    sConfigADC.Rank          = 2;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;
  
    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }
  
    /* Configure ADC channel PC1, REF_CELL_1 */
    sConfigADC.Channel       = ADC_CHANNEL_11;
    sConfigADC.Rank          = 3;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }

    /* Configure ADC channel PC2, REF_CELL_2 */
    sConfigADC.Channel       = ADC_CHANNEL_12;
    sConfigADC.Rank          = 4;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }

    /* Configure ADC channel PC3, REF_CELL_3 */
    sConfigADC.Channel       = ADC_CHANNEL_13;
    sConfigADC.Rank          = 5;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }

    /* Configure ADC channel PA1, IMON_0 */
    sConfigADC.Channel       = ADC_CHANNEL_1;
    sConfigADC.Rank          = 6;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }

    /* Configure ADC channel PA2, IMON_1 */
    sConfigADC.Channel       = ADC_CHANNEL_2;
    sConfigADC.Rank          = 7;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {   
        nError_Handler();
    }
  
    /* Configure ADC channel PA3, VMON */
    sConfigADC.Channel       = ADC_CHANNEL_3;
    sConfigADC.Rank          = 8;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }

    /* Configure ADC channel PA6, IMON_2 */
    sConfigADC.Channel       = ADC_CHANNEL_6;
    sConfigADC.Rank          = 10;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }
  
    /* Configure ADC channel PA7, IMON_3 */
    sConfigADC.Channel       = ADC_CHANNEL_7;
    sConfigADC.Rank          = 11;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }
  
    /* Configure ADC channel PA14, Temperature */
    sConfigADC.Channel       = ADC_CHANNEL_14;
    sConfigADC.Rank          = 9;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }
   
    /* Configure ADC channel PA15, NODE_ADDR */
    sConfigADC.Channel       = ADC_CHANNEL_15;
    sConfigADC.Rank          = 1;
    sConfigADC.SamplingTime  = ADC_SAMPLETIME_15CYCLES;
    sConfigADC.Offset        = 0;

    if (HAL_ADC_ConfigChannel(&hADC1, &sConfigADC) != HAL_OK)
    {
        nError_Handler();
    }
  
    if (HAL_ADC_Start_IT(&hADC1) != HAL_OK)
    {
        nError_Handler();
    }
}
/*=============================================================================
 *  DAC Configuration
 *===========================================================================*/
static void DAC_Init(void)
{
    hDAC.Instance = DAC;
  
    if (HAL_DAC_Init(&hDAC) != HAL_OK)
    {
        nError_Handler();
    }
  
    sConfigDAC.DAC_OutputBuffer =  DAC_OUTPUTBUFFER_ENABLE;
    sConfigDAC.DAC_Trigger      =  DAC_TRIGGER_NONE;

    if (HAL_DAC_ConfigChannel(&hDAC, &sConfigDAC, DAC_CHANNEL_1) != HAL_OK)
    {
        nError_Handler();
    }

    if (HAL_DAC_Start(&hDAC, DAC_CHANNEL_1) != HAL_OK)
    {
        nError_Handler();
    }
}
/*=============================================================================
 *  end of file
 *===========================================================================*/

